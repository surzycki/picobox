#!/bin/bash
#
# setup picobox proxies
#
# normally extensions are here this is just a test stub